// Código que escreve na tela a mensagem de Vencedor

function venceu() {
  textAlign(CENTER);
  textSize(40);
  textStyle(BOLD);
  fill("green");
  text("VENCEDOR!!!", 245, 175)
}